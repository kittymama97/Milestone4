﻿//Andreea Condrut
//This is my own work
// CST 117
using Milestone3;
using System;
using System.Data;
using System.Windows.Forms;

namespace Milestone4
{
    public partial class Form1 : Form
    {
        private InventoryManager im = new InventoryManager();
        private DataTable inventoryDataTable;
        private DataTable manufacturerTable;
        //private int currentTabIndex = -1;

        public Form1()
        {
            InitializeComponent();
            //get the data table
            inventoryDataTable = this.getDataTable();
            //set the data table as the data source for grid
            this.dataGridView1.DataSource = inventoryDataTable;

        }

        private DataTable getDataTable()
        {
            DataTable tb1 = new DataTable();

            tb1.Columns.Add("Item ID", typeof(string));
            tb1.Columns.Add("Name", typeof(string));
            tb1.Columns.Add("Price", typeof(double));
            tb1.Columns.Add("Quantity Available", typeof(int));
            tb1.Columns.Add("Manufacturer", typeof(string));
            tb1.Columns.Add("Description", typeof(string));

            // here we add five data rows 
            //for each item in the inventory manager
            foreach (InventoryItem item in im.toArray())
            {
                //add the properties to a row in the table
                tb1.Rows.Add(item.ItemId, item.Name, item.PricePerItem, item.QuantityAvailable, item.Manufacturer, item.Description);
            }
            return tb1;
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            //if the add tab is selected we populate the combobox with the manufacturers
            if (tabControl1.SelectedTab == add_tab)
            {
                manufacturerTable = this.getManufacturerTable();

                foreach (DataRow dr in manufacturerTable.Rows)
                {
                    this.comboManufacturer.Items.Add(dr["Manufacturer"]);
                }
            }

            if (tabControl1.SelectedTab == home_tab)
            {
                //resets the table and performs add, remove, restock and search on the home tab 
                this.inventoryDataTable = this.getDataTable();
                this.dataGridView1.DataSource = this.inventoryDataTable;
            }

            if (tabControl1.SelectedTab == remove_tab)
            {

            }

            if (tabControl1.SelectedTab == restock_tab)
            {

            }

            if (tabControl1.SelectedTab == search_tab)
            {

            }
        }

        private DataTable getManufacturerTable()
        {
            //make new data tab;e
            DataTable tbl = new DataTable();
            //add manufacturer column
            tbl.Columns.Add("Manufacturer");
            //create streamreader
            System.IO.StreamReader sr = new System.IO.StreamReader("GunManufacturers.txt");
            //read a line from the text file
            string str = sr.ReadLine();
            //while loop to go through all the lines in the textfile
            while (!sr.EndOfStream)
            {
                //adds all the lines to the table
                tbl.Rows.Add(str);

                str = sr.ReadLine();
            }
            return tbl;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string itemId = this.textBoxID.Text;
            string name = this.textBoxName.Text;
            string pricePerItem = this.textBoxPrice.Text;
            string quantityAvailable = this.textBoxQuantity.Text;
            string description = this.textBoxDescription.Text;
            //new inventory item
            InventoryItem item = new InventoryItem();

            try
            {
                item.PricePerItem = double.Parse(pricePerItem);

                try
                {
                    item.QuantityAvailable = int.Parse(quantityAvailable);
                    item.Name = name;
                    MessageBox.Show("Added: \n" + item + "\nto your inventory.");

                }

                catch
                {
                    MessageBox.Show("Item stock must be an integer value");

                }
                }

                catch
                {
                    MessageBox.Show("Input must be of numeric value.");
                }
                
            //adds items to the datagrid
            im.addItem(item);

            inventoryDataTable = getDataTable();

            this.dataGridView1.DataSource = this.inventoryDataTable;
        }

        //method to remove an item
        private void removeButton_Click()
        {
            //populate a combobox with all inventory items
            //remove selected item
        }
        //method to restock an item
        private void restockButton_Click()
        {
            //populate a combobox with all inventory items
            //get value from textbox
            //add value from textbox to inventory item selected
        }
        //method to search for an item using name
        private void searchNameButton_Click()
        {
            //get search criteria from textbox
            //return the search
        }
        //return null if not found

        //method to search for an item using price
        private void searchPriceButton_Click()
        {

            //get search criteria by price
            //return the search if true
        }
        //return null if not found
    }
}






