﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone3
{
    class InventoryManager
    {
        private List<InventoryItem> item;

        public object PricePerItem { get; private set; }

        public InventoryManager()
        {
            item = new List<InventoryItem>();

            // add items to the manager for testing
            // make an inventory item

            InventoryItem i1 = new InventoryItem();
            i1.ItemId = "1";
            i1.Name = "Thunder 380";
            i1.PricePerItem = 299.99;
            i1.QuantityAvailable = 30;
            i1.Manufacturer = "Bersa";
            i1.Description = "Pretty gun, perfect for women";
            item.Add(i1);

            InventoryItem i2 = new InventoryItem();
            i2.ItemId = "2";
            i2.Name = "9mm";
            i2.PricePerItem = 699.99;
            i2.QuantityAvailable = 18;
            i2.Manufacturer = "Ruger";
            i2.Description = "Pretty pink gun";
            item.Add(i2);

            InventoryItem i3 = new InventoryItem();
            i3.ItemId = "3";
            i3.Name = "Bodyguard";
            i3.PricePerItem = 270.99;
            i3.QuantityAvailable = 14;
            i3.Manufacturer = "Smith & Wesson";
            i3.Description = "Compact 180 gun";
            item.Add(i3);

            InventoryItem i4 = new InventoryItem();
            i4.ItemId = "4";
            i4.Name = "Glock 43";
            i4.PricePerItem = 450.00;
            i4.QuantityAvailable = 65;
            i4.Manufacturer = "Glock";
            i4.Description = "Shiny, black 9mm automatic gun";
            item.Add(i4);

        }

        public void addItem(InventoryItem item)
        {
            int location = find(item);
            if (location == -1)
                //add item
                this.item.Add(item);
            // if I find it get the index and increase the stock
            else
                this.item[location].QuantityAvailable += item.QuantityAvailable;
        }

        public bool removeItem(InventoryItem item)
        {
            return this.item.Remove(item);
        }

        // restock items
        public void restockItems(InventoryItem item)
        {
            int location = find(item);
            if (location == 0)
            {
                this.item.Add(item);
            }
            else this.item[location].QuantityAvailable += item.QuantityAvailable;

        }

        //method to find the item and return the index
        public int find(InventoryItem item)
        {
            for (int i = 0; i < this.item.Count; i++)
            {
                if (item.Equals(this.item[i]))
                    return 1;
            }
            return -1;
        }
        public void PrintItems()
        {
            for (int i = 0; i < item.Count; i++)
            {
                Console.WriteLine(item);
            }
        }


        public InventoryItem findByPrice(double price)
        {
            for (int i = 0; i < item.Count; i++)
            {
                if (item[i].PricePerItem == price)
                    return null;
            }
                return null;
            
        }

        public InventoryItem findByName(string Name)
        {
            for (int i = 0; i < item.Count; i++)
            {
                if (item[i].Name == Name)
                    return item[i];
            }
            return null;

        }
            

        


        public InventoryItem[] toArray()
        {
            InventoryItem[] itemList = new InventoryItem[item.Count];
            int i = 0;
            foreach (InventoryItem item in item)
            {
                itemList[i++] = item;

            }
            return itemList;

        }
    }
}
    


