﻿

using System;

namespace Milestone3
{
    public class InventoryItem
    {

        public string ItemId { set; get; }
        public string Name { set; get; }
        public double PricePerItem { set; get; }
        public int QuantityAvailable { set; get; }
        public string Manufacturer { set; get; }
        public string Description { set; get; }
        

        public InventoryItem()
        {

        }
        
        // sell an item method
        public bool SellItem()
        {
            if (QuantityAvailable > 0)
            {
                QuantityAvailable--;
                return true;
            }
            return false;
        }
        public override string ToString()
        {
            return ItemId + ":" + Name + ":" + PricePerItem + ": " + QuantityAvailable + ":" + Manufacturer + ": " + Description + ":";
        }
        public override bool Equals(object obj)
        {
            //make sure that obj is an inventory item
            if (obj is InventoryItem)
            {
                //cast obj to an inventory item
                InventoryItem item = (InventoryItem)obj;
                if (item.ItemId == ItemId && item.Name == Name && item.PricePerItem == PricePerItem && item.QuantityAvailable == QuantityAvailable && item.Manufacturer == Manufacturer && item.Description == Description)
                    return true;
                
            }
            return false;

        }
    }
}


