﻿namespace Milestone4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.home_tab = new System.Windows.Forms.TabPage();
            this.gridPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.add_tab = new System.Windows.Forms.TabPage();
            this.comboManufacturer = new System.Windows.Forms.ComboBox();
            this.addButton = new System.Windows.Forms.Button();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.labelDescription = new System.Windows.Forms.Label();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.labelManufacturer = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.remove_tab = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.comboRemove = new System.Windows.Forms.ComboBox();
            this.restock_tab = new System.Windows.Forms.TabPage();
            this.restockButton = new System.Windows.Forms.Button();
            this.textBoxRestock = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboRestock = new System.Windows.Forms.ComboBox();
            this.search_tab = new System.Windows.Forms.TabPage();
            this.searchNameButton = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.searchPriceButton = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.home_tab.SuspendLayout();
            this.gridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.add_tab.SuspendLayout();
            this.remove_tab.SuspendLayout();
            this.restock_tab.SuspendLayout();
            this.search_tab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.home_tab);
            this.tabControl1.Controls.Add(this.add_tab);
            this.tabControl1.Controls.Add(this.remove_tab);
            this.tabControl1.Controls.Add(this.restock_tab);
            this.tabControl1.Controls.Add(this.search_tab);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(796, 256);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // home_tab
            // 
            this.home_tab.Controls.Add(this.gridPanel);
            this.home_tab.Location = new System.Drawing.Point(4, 22);
            this.home_tab.Name = "home_tab";
            this.home_tab.Padding = new System.Windows.Forms.Padding(3);
            this.home_tab.Size = new System.Drawing.Size(788, 230);
            this.home_tab.TabIndex = 0;
            this.home_tab.Text = "Home";
            this.home_tab.UseVisualStyleBackColor = true;
            // 
            // gridPanel
            // 
            this.gridPanel.Controls.Add(this.dataGridView1);
            this.gridPanel.Location = new System.Drawing.Point(6, 6);
            this.gridPanel.Name = "gridPanel";
            this.gridPanel.Size = new System.Drawing.Size(776, 218);
            this.gridPanel.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(776, 218);
            this.dataGridView1.TabIndex = 0;
            // 
            // add_tab
            // 
            this.add_tab.Controls.Add(this.comboManufacturer);
            this.add_tab.Controls.Add(this.addButton);
            this.add_tab.Controls.Add(this.textBoxDescription);
            this.add_tab.Controls.Add(this.labelDescription);
            this.add_tab.Controls.Add(this.textBoxQuantity);
            this.add_tab.Controls.Add(this.textBoxPrice);
            this.add_tab.Controls.Add(this.textBoxName);
            this.add_tab.Controls.Add(this.textBoxID);
            this.add_tab.Controls.Add(this.labelManufacturer);
            this.add_tab.Controls.Add(this.labelQuantity);
            this.add_tab.Controls.Add(this.labelPrice);
            this.add_tab.Controls.Add(this.labelName);
            this.add_tab.Controls.Add(this.labelID);
            this.add_tab.Location = new System.Drawing.Point(4, 22);
            this.add_tab.Name = "add_tab";
            this.add_tab.Padding = new System.Windows.Forms.Padding(3);
            this.add_tab.Size = new System.Drawing.Size(788, 230);
            this.add_tab.TabIndex = 1;
            this.add_tab.Text = "Add Item";
            this.add_tab.UseVisualStyleBackColor = true;
            // 
            // comboManufacturer
            // 
            this.comboManufacturer.FormattingEnabled = true;
            this.comboManufacturer.Location = new System.Drawing.Point(482, 21);
            this.comboManufacturer.Name = "comboManufacturer";
            this.comboManufacturer.Size = new System.Drawing.Size(121, 21);
            this.comboManufacturer.TabIndex = 14;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(507, 177);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 12;
            this.addButton.Text = "Add Item";
            this.addButton.UseVisualStyleBackColor = true;
            // 
            // textBoxDescription
            // 
            this.textBoxDescription.Location = new System.Drawing.Point(482, 70);
            this.textBoxDescription.Name = "textBoxDescription";
            this.textBoxDescription.Size = new System.Drawing.Size(100, 20);
            this.textBoxDescription.TabIndex = 11;
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.Location = new System.Drawing.Point(370, 77);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(86, 13);
            this.labelDescription.TabIndex = 10;
            this.labelDescription.Text = "Item Description:";
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(185, 170);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(100, 20);
            this.textBoxQuantity.TabIndex = 8;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(185, 124);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrice.TabIndex = 7;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(185, 70);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(100, 20);
            this.textBoxName.TabIndex = 6;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(185, 21);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 20);
            this.textBoxID.TabIndex = 5;
            // 
            // labelManufacturer
            // 
            this.labelManufacturer.AutoSize = true;
            this.labelManufacturer.Location = new System.Drawing.Point(370, 28);
            this.labelManufacturer.Name = "labelManufacturer";
            this.labelManufacturer.Size = new System.Drawing.Size(96, 13);
            this.labelManufacturer.TabIndex = 4;
            this.labelManufacturer.Text = "Item Manufacturer:";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(75, 177);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(75, 13);
            this.labelQuantity.TabIndex = 3;
            this.labelQuantity.Text = "Item Quantity: ";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(75, 131);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(57, 13);
            this.labelPrice.TabIndex = 2;
            this.labelPrice.Text = "Item Price:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(75, 77);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(64, 13);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Item Name: ";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(75, 28);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(47, 13);
            this.labelID.TabIndex = 0;
            this.labelID.Text = "Item ID: ";
            // 
            // remove_tab
            // 
            this.remove_tab.Controls.Add(this.label3);
            this.remove_tab.Controls.Add(this.comboRemove);
            this.remove_tab.Location = new System.Drawing.Point(4, 22);
            this.remove_tab.Name = "remove_tab";
            this.remove_tab.Padding = new System.Windows.Forms.Padding(3);
            this.remove_tab.Size = new System.Drawing.Size(788, 230);
            this.remove_tab.TabIndex = 2;
            this.remove_tab.Text = "Remove Item";
            this.remove_tab.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(139, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Choose Item To Remove:";
            // 
            // comboRemove
            // 
            this.comboRemove.FormattingEnabled = true;
            this.comboRemove.Location = new System.Drawing.Point(142, 56);
            this.comboRemove.Name = "comboRemove";
            this.comboRemove.Size = new System.Drawing.Size(121, 21);
            this.comboRemove.TabIndex = 0;
            // 
            // restock_tab
            // 
            this.restock_tab.Controls.Add(this.restockButton);
            this.restock_tab.Controls.Add(this.textBoxRestock);
            this.restock_tab.Controls.Add(this.label2);
            this.restock_tab.Controls.Add(this.label1);
            this.restock_tab.Controls.Add(this.comboRestock);
            this.restock_tab.Location = new System.Drawing.Point(4, 22);
            this.restock_tab.Name = "restock_tab";
            this.restock_tab.Padding = new System.Windows.Forms.Padding(3);
            this.restock_tab.Size = new System.Drawing.Size(788, 230);
            this.restock_tab.TabIndex = 3;
            this.restock_tab.Text = "Restock Item";
            this.restock_tab.UseVisualStyleBackColor = true;
            // 
            // restockButton
            // 
            this.restockButton.Location = new System.Drawing.Point(215, 175);
            this.restockButton.Name = "restockButton";
            this.restockButton.Size = new System.Drawing.Size(75, 23);
            this.restockButton.TabIndex = 4;
            this.restockButton.Text = "Restock";
            this.restockButton.UseVisualStyleBackColor = true;
            // 
            // textBoxRestock
            // 
            this.textBoxRestock.Location = new System.Drawing.Point(337, 68);
            this.textBoxRestock.Name = "textBoxRestock";
            this.textBoxRestock.Size = new System.Drawing.Size(100, 20);
            this.textBoxRestock.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(334, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter quantity to be restocked: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose Item To Restock:";
            // 
            // comboRestock
            // 
            this.comboRestock.FormattingEnabled = true;
            this.comboRestock.Location = new System.Drawing.Point(54, 67);
            this.comboRestock.Name = "comboRestock";
            this.comboRestock.Size = new System.Drawing.Size(121, 21);
            this.comboRestock.TabIndex = 0;
            // 
            // search_tab
            // 
            this.search_tab.Controls.Add(this.searchPriceButton);
            this.search_tab.Controls.Add(this.searchNameButton);
            this.search_tab.Controls.Add(this.textBox2);
            this.search_tab.Controls.Add(this.textBox1);
            this.search_tab.Controls.Add(this.label5);
            this.search_tab.Controls.Add(this.label4);
            this.search_tab.Location = new System.Drawing.Point(4, 22);
            this.search_tab.Name = "search_tab";
            this.search_tab.Size = new System.Drawing.Size(788, 230);
            this.search_tab.TabIndex = 4;
            this.search_tab.Text = "Search";
            this.search_tab.UseVisualStyleBackColor = true;
            // 
            // searchNameButton
            // 
            this.searchNameButton.Location = new System.Drawing.Point(36, 150);
            this.searchNameButton.Name = "searchNameButton";
            this.searchNameButton.Size = new System.Drawing.Size(75, 23);
            this.searchNameButton.TabIndex = 4;
            this.searchNameButton.Text = "Search";
            this.searchNameButton.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(36, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(346, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(343, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Search By Price:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Search By Name: ";
            // 
            // searchPriceButton
            // 
            this.searchPriceButton.Location = new System.Drawing.Point(346, 150);
            this.searchPriceButton.Name = "searchPriceButton";
            this.searchPriceButton.Size = new System.Drawing.Size(75, 23);
            this.searchPriceButton.TabIndex = 5;
            this.searchPriceButton.Text = "Search";
            this.searchPriceButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 261);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.home_tab.ResumeLayout(false);
            this.gridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.add_tab.ResumeLayout(false);
            this.add_tab.PerformLayout();
            this.remove_tab.ResumeLayout(false);
            this.remove_tab.PerformLayout();
            this.restock_tab.ResumeLayout(false);
            this.restock_tab.PerformLayout();
            this.search_tab.ResumeLayout(false);
            this.search_tab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage home_tab;
        private System.Windows.Forms.TabPage add_tab;
        private System.Windows.Forms.Panel gridPanel;
        private System.Windows.Forms.TabPage remove_tab;
        private System.Windows.Forms.TabPage restock_tab;
        private System.Windows.Forms.TabPage search_tab;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelManufacturer;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.ComboBox comboManufacturer;
        private System.Windows.Forms.Button restockButton;
        private System.Windows.Forms.TextBox textBoxRestock;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboRestock;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboRemove;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button searchNameButton;
        private System.Windows.Forms.Button searchPriceButton;
    }
}

